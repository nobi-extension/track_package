"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
init();
function init() {
    var _a, _b;
    const container = document.getElementById('container');
    const m = document.location.search.match(/[?&]code\=([^&]+)/);
    if (m == null) {
        return error('追跡番号が指定されていません。');
    }
    const rawCode = decodeURIComponent(m[1]);
    const code = (_b = (_a = rawCode.replace(/-/g, '').match(/[0-9A-Z]{10,}/)) === null || _a === void 0 ? void 0 : _a[0]) !== null && _b !== void 0 ? _b : null;
    if (code === null) {
        return error(`「${rawCode} 」 は有効な追跡番号ではありません。`);
    }
    const links = {
        'ヤマト運輸': `https://jizen.kuronekoyamato.co.jp/jizen/servlet/crjz.b.NQ0010?id=${code}`,
        '佐川急便': `https://k2k.sagawa-exp.co.jp/p/web/okurijosearch.do?okurijoNo=${code}`,
        '日本郵政': `https://trackings.post.japanpost.jp/services/srv/search/direct?locale=ja&reqCodeNo1=${code}`,
        '福山通運': `https://corp.fukutsu.co.jp/situation/tracking_no_hunt/${code}`,
    };
    const hrefs = [];
    for (const [name, href] of Object.entries(links)) {
        const p = document.createElement('p');
        p.classList.add('item');
        container.append(p);
        const a = document.createElement('a');
        p.append(a);
        a.href = href;
        hrefs.push(href);
        a.target = '_blank';
        const spanTitle = document.createElement('span');
        spanTitle.classList.add('title');
        spanTitle.textContent = `${name}の荷物 ${format(code)} を追跡`;
        const spanURL = document.createElement('span');
        spanURL.classList.add('url');
        spanURL.textContent = href;
        a.append(spanTitle, document.createElement('br'), spanURL);
    }
    const pAll = document.createElement('p');
    pAll.classList.add('item');
    pAll.innerHTML = `<a><span class="title">すべてのリンクを開く</span></a>`;
    pAll.addEventListener('click', ev => {
        if (window.confirm(`${hrefs.length}件のリンクをすべて開きますか?`)) {
            ev.preventDefault();
            openAll();
        }
    });
    container.append(pAll);
    function error(msg) {
        const p = document.createElement('p');
        p.classList.add('error');
        p.textContent = msg;
        container.append(p);
    }
    function format(code) {
        if (/^\d{12}$/.test(code)) {
            return code.split(/(?<=^(?:\d{4})+)/).join('-');
        }
        else {
            return code;
        }
    }
    function openAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const tab = yield chrome.tabs.getCurrent();
            let index = tab === null || tab === void 0 ? void 0 : tab.index;
            if (index != null)
                index += 1;
            for (const href of hrefs.reverse()) {
                chrome.tabs.create({ url: href, index, active: true });
            }
        });
    }
}
